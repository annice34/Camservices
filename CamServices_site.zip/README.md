# CamServices

Site vitrine + annuaire de services, conçu pour être hébergé gratuitement.

## Fonctionnement de cette version
- Recherche et filtres
- Annonces de démonstration
- Formulaire de publication
- Contact WhatsApp
- Stockage local dans le navigateur
- Section de monétisation

## Pour une vraie version publique
Le stockage `localStorage` doit être remplacé par une base de données et une authentification. Il faudra aussi un hébergement et, si vous voulez vendre des mises en avant, intégrer un prestataire de paiement compatible avec votre pays et vos conditions.

## Déploiement gratuit
Vous pouvez publier les fichiers sur un hébergeur statique gratuit qui accepte un dépôt Git. Les fichiers nécessaires sont `index.html`, `styles.css` et `app.js`.

## Important
Le site ne garantit pas 500 € de revenus. Les revenus dépendront notamment du trafic, de la demande, de la qualité des services et de la monétisation choisie.
