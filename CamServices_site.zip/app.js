const defaultServices=[
 {name:"Merveille Cuisine",title:"Gâteaux & plats sur commande",category:"Cuisine",city:"Yaoundé",price:"À partir de 5 000 FCFA",phone:"237600000001",description:"Gâteaux d'anniversaire, plats et commandes pour événements."},
 {name:"Beauty Grace",title:"Coiffure à domicile",category:"Beauté",city:"Douala",price:"À partir de 3 000 FCFA",phone:"237600000002",description:"Coiffure et mise en beauté à domicile sur rendez-vous."},
 {name:"Tech Express",title:"Réparation de téléphones",category:"Réparation",city:"Yaoundé",price:"Devis gratuit",phone:"237600000003",description:"Diagnostic, réparation et remplacement de pièces selon disponibilité."},
 {name:"Design Pro",title:"Création de logos & affiches",category:"Digital",city:"Bafoussam",price:"À partir de 5 000 FCFA",phone:"237600000004",description:"Visuels pour entreprises, événements et réseaux sociaux."},
 {name:"Rapide Livraison",title:"Livraison en ville",category:"Livraison",city:"Douala",price:"À partir de 1 500 FCFA",phone:"237600000005",description:"Petites livraisons et courses en ville."},
 {name:"Maison Clean",title:"Nettoyage à domicile",category:"Maison",city:"Yaoundé",price:"Sur devis",phone:"237600000006",description:"Nettoyage de maisons, bureaux et petits locaux."}
];

function getServices(){return JSON.parse(localStorage.getItem("camservices")||"null")||defaultServices}
function saveServices(x){localStorage.setItem("camservices",JSON.stringify(x))}
function wa(phone,title){return "https://wa.me/"+phone.replace(/\D/g,"")+"?text="+encodeURIComponent("Bonjour, je suis intéressé(e) par votre service : "+title)}
function render(items=getServices()){
 const grid=document.getElementById("serviceGrid"); document.getElementById("resultCount").textContent=items.length+" annonce(s)";
 if(!items.length){grid.innerHTML='<div class="empty">Aucun service trouvé. Essayez un autre mot-clé ou une autre catégorie.</div>';return}
 grid.innerHTML=items.map(s=>`<article class="card"><span class="tag">${escapeHtml(s.category)}</span><h3>${escapeHtml(s.title)}</h3><div class="meta"><b>${escapeHtml(s.name)}</b> · ${escapeHtml(s.city)}</div><p>${escapeHtml(s.description)}</p><div class="price">${escapeHtml(s.price||"Prix à discuter")}</div><a class="btn contact" target="_blank" rel="noopener" href="${wa(s.phone,s.title)}">Contacter sur WhatsApp</a></article>`).join("")
}
function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function filterServices(){
 const q=document.getElementById("search").value.toLowerCase().trim(), c=document.getElementById("category").value;
 render(getServices().filter(s=>(!q||[s.name,s.title,s.city,s.category,s.description].join(" ").toLowerCase().includes(q))&&(!c||s.category===c)))
}
document.getElementById("listingForm").addEventListener("submit",e=>{
 e.preventDefault(); const data=Object.fromEntries(new FormData(e.target).entries()); const all=getServices(); all.unshift(data); saveServices(all); e.target.reset(); render(); location.hash="services"; alert("Annonce ajoutée sur cet appareil. Pour la rendre publique à tous, connectez le site à une base de données."); 
});
document.getElementById("search").addEventListener("input",filterServices);
document.getElementById("category").addEventListener("change",filterServices);
render();
